let express = require("express");
const User = require("../models/User");
let router =  express.Router();

router.post("/",(req,res)=>{
  let user = new User(req.body);
  user.save().then((result)=>{
      res.json({status:"success", data:result});
  }, (err)=>{
      res.json({status:"failed", data:err});
  });
});

router.get("/", (req, res)=>{
  User.find().then((result)=>{
    res.json({status:"success", data:result});
  }, (err)=>{
    res.json({status:"failed", data:err});
  });

});
router.get("/:id",(req,res)=>{
  User.findById(req.params.id).then((result)=>{
      res.json({status:"success", data:result});
  }, (err)=>{
      res.json({status:"failed", data:err});
  });
});

router.put("/:id",(req,res)=>{
  User.findByIdAndUpdate(req.params.id, req.body).then((result)=>{
      res.json({status:"success", data:req.body});
  }, (err)=>{
      res.json({status:"failed", data:err});
  });
});

router.delete("/:id",(req,res)=>{
  User.findByIdAndDelete(req.params.id).then((result)=>{
      res.json({status:"success", data:result});
  }, (err)=>{
      res.json({status:"failed", data:err});
  });
});

module.exports = router;
