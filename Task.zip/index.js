let express = require("express");
let bodyparser = require("body-parser");
let mongoose = require("mongoose");

let app = express();
app.use(express.json());
mongoose.connect("mongodb://127.0.0.1:27017/sample");
let db = mongoose.connection;


db.on("error", (err)=>{
    console.log("Database Connection Error");

});

db.on("open", ()=>{
    console.log("Connection Opened");   
});

app.use("/users", require("./routes/users"));

app.listen(8081, ()=>{
    console.log("Server is running on http://localhost:8081");
});


